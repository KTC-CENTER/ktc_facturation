-- Add payment fields to invoices table
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS payment_method VARCHAR(100) DEFAULT NULL;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS payment_reference VARCHAR(255) DEFAULT NULL;
